
import React, { useState, useEffect } from 'react';
import { Track, TrackVersion } from '../types';
import WaveformVisualizer from './WaveformVisualizer';

interface TrackDetailProps {
  track: Track;
  isPlaying: boolean;
  currentAudioUrl?: string;
  onPlayToggle: () => void;
  onPlayVersion: (track: Track, version: TrackVersion) => void;
  onBack: () => void;
  onArtistClick: (artistId: string) => void;
  onLike: () => void;
}

const TrackDetail: React.FC<TrackDetailProps> = ({ 
  track, 
  isPlaying, 
  currentAudioUrl,
  onPlayToggle, 
  onPlayVersion,
  onBack, 
  onArtistClick, 
  onLike 
}) => {
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    const audioEl = document.querySelector('audio');
    if (!audioEl) return;
    
    const updateProgress = () => setProgress(audioEl.currentTime / audioEl.duration || 0);
    audioEl.addEventListener('timeupdate', updateProgress);

    if (!analyser) {
      try {
        const ctx = (window as any).audioContext || new (window.AudioContext || (window as any).webkitAudioContext)();
        (window as any).audioContext = ctx;
        
        if (ctx.state === 'suspended') {
          const resume = () => ctx.resume().then(() => document.removeEventListener('click', resume));
          document.addEventListener('click', resume);
        }

        const node = ctx.createAnalyser();
        node.fftSize = 256;
        
        if (!(window as any).audioSourceConnected) {
          const source = ctx.createMediaElementSource(audioEl);
          source.connect(node);
          node.connect(ctx.destination);
          (window as any).audioSourceConnected = true;
        }
        
        setAnalyser(node);
      } catch (e) {
        console.warn("Visualizer connection failed:", e);
      }
    }
    return () => audioEl.removeEventListener('timeupdate', updateProgress);
  }, [track, analyser]);

  const handleSeek = (newProgress: number) => {
    const audioEl = document.querySelector('audio');
    if (audioEl && audioEl.duration) audioEl.currentTime = newProgress * audioEl.duration;
  };

  const handleDownload = (version: TrackVersion | Track) => {
    const link = document.createElement('a');
    link.href = version.audioUrl;
    link.download = `${track.artist} - ${track.title}.wav`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const isOriginalActive = isPlaying && (!currentAudioUrl || currentAudioUrl === track.audioUrl);

  return (
    <div className="animate-in fade-in duration-500 max-w-[1000px] mx-auto pb-48">
      {/* Release Top Bar */}
      <div className="px-4 py-6 flex items-center justify-between border-b border-white/5 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-[#ff5500] rounded-xl flex items-center justify-center shadow-lg shadow-[#ff5500]/20">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 19V6l12-3v13"/></svg>
          </div>
          <span className="font-outfit font-bold tracking-tight text-white text-2xl uppercase">Release Detail</span>
        </div>
        
        <button 
          onClick={onBack} 
          className="flex items-center gap-2 text-zinc-500 hover:text-white transition-colors group"
        >
          <span className="text-[10px] font-black uppercase tracking-widest">Back to Catalog</span>
          <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" strokeWidth={2.5}/></svg>
        </button>
      </div>

      <div className="px-4 grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Column: Waveform, Actions */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Track Identity Header */}
          <div className="mb-4">
            <h1 className="text-4xl md:text-6xl font-black text-white leading-none tracking-tighter mb-2 uppercase">
              {track.title}
            </h1>
            <h2 
              onClick={() => onArtistClick(track.artistId)}
              className="text-xl md:text-2xl font-bold text-[#ff5500] uppercase tracking-[0.2em] cursor-pointer hover:text-white transition-colors"
            >
              {track.artist}
            </h2>
          </div>

          {/* Deck Waveform View */}
          <div className="bg-zinc-900/40 rounded-[40px] p-8 border border-white/5 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-100 transition-opacity">
               <span className="text-[10px] font-black text-white uppercase tracking-widest">{track.format || 'Hi-Res'}</span>
            </div>
            
            <div className="w-full h-36 mb-10 relative">
              <WaveformVisualizer 
                peaks={track.peaks || []} 
                progress={progress} 
                onSeek={handleSeek} 
                isPlaying={isPlaying} 
                analyser={analyser} 
                duration={track.duration}
              />
            </div>
            
            <div className="flex items-center gap-5">
              <button 
                onClick={onPlayToggle}
                className={`w-16 h-16 rounded-3xl flex items-center justify-center transition-all shadow-xl ${isOriginalActive ? 'bg-[#ff5500] text-white' : 'bg-white text-black hover:bg-zinc-200'}`}
              >
                {isOriginalActive ? (
                  <svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                ) : (
                  <svg className="w-7 h-7 ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                )}
              </button>

              <button 
                onClick={onLike} 
                className={`flex flex-col items-center justify-center gap-1 bg-zinc-800/80 border border-white/5 w-24 h-16 rounded-3xl transition-all ${track.isLiked ? 'text-[#ff5500] border-[#ff5500]/30' : 'text-zinc-500 hover:text-white'}`}
              >
                <svg className={`w-5 h-5 ${track.isLiked ? 'fill-current' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                </svg>
                <span className="text-[10px] font-black uppercase tracking-widest">{track.likeCount || 0}</span>
              </button>
              
              <button 
                onClick={() => handleDownload(track)} 
                className="flex-1 bg-[#ff5500] text-white h-16 rounded-3xl font-black uppercase text-sm tracking-[0.2em] hover:brightness-110 active:scale-[0.98] transition-all shadow-2xl shadow-[#ff5500]/20 flex items-center justify-center gap-3"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0L8 8m4-4v12" strokeWidth={2.5}/></svg>
                Download WAV
              </button>
            </div>
          </div>

          {/* Metadata Info Bar */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-zinc-950 border border-white/5 p-5 rounded-3xl text-center shadow-lg">
              <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-2">Beat Grid</span>
              <span className="text-2xl font-black text-white">{track.bpm} <span className="text-xs text-zinc-700">BPM</span></span>
            </div>
            <div className="bg-zinc-950 border border-white/5 p-5 rounded-3xl text-center shadow-lg">
              <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-2">Musical Key</span>
              <span className="text-2xl font-black text-white">{track.key}</span>
            </div>
            <div className="bg-zinc-950 border border-white/5 p-5 rounded-3xl text-center shadow-lg">
              <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-2">Category</span>
              <span className="text-[11px] font-black text-white uppercase tracking-widest block py-2">{track.genre}</span>
            </div>
          </div>

          {/* Version Selector List */}
          <div className="space-y-6">
            <h3 className="text-[11px] font-black uppercase text-zinc-500 tracking-[0.4em] px-3">Available Mixes</h3>
            <div className="space-y-4">
              {track.versions && track.versions.length > 0 ? track.versions.map(v => {
                const isThisActive = isPlaying && currentAudioUrl === v.audioUrl;
                return (
                  <div 
                    key={v.id} 
                    onClick={() => onPlayVersion(track, v)}
                    className={`flex items-center gap-6 p-5 rounded-[32px] border transition-all cursor-pointer group ${isThisActive ? 'bg-[#ff5500]/10 border-[#ff5500]/40 shadow-xl' : 'bg-zinc-900/40 border-white/5 hover:border-white/10'}`}
                  >
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center shrink-0 shadow-2xl transition-all ${isThisActive ? 'bg-[#ff5500] text-white' : 'bg-[#ff5500] text-white opacity-90 group-hover:opacity-100 group-hover:scale-105'}`}>
                      {isThisActive ? (
                        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                      ) : (
                        <svg className="w-6 h-6 ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className={`text-base font-black truncate ${isThisActive ? 'text-[#ff5500]' : 'text-white'}`}>
                        {v.name}
                      </h4>
                      <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-0.5">
                        {v.duration} • {v.format}
                      </p>
                    </div>
                    <div className="flex items-center gap-5">
                      <div className="flex items-end gap-[4px] h-5">
                        <div className={`w-[3px] bg-[#ff5500] rounded-full transition-all duration-300 ${isThisActive ? 'h-full animate-bar-bounce' : 'h-1/2 opacity-20'}`} style={{ animationDelay: '0ms' }} />
                        <div className={`w-[3px] bg-[#ff5500] rounded-full transition-all duration-300 ${isThisActive ? 'h-3/4 animate-bar-bounce' : 'h-1/3 opacity-20'}`} style={{ animationDelay: '150ms' }} />
                        <div className={`w-[3px] bg-[#ff5500] rounded-full transition-all duration-300 ${isThisActive ? 'h-full animate-bar-bounce' : 'h-1/2 opacity-20'}`} style={{ animationDelay: '300ms' }} />
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDownload(v); }} 
                        className="w-12 h-12 bg-zinc-800/80 hover:bg-[#ff5500] rounded-2xl flex items-center justify-center text-zinc-300 hover:text-white transition-all border border-white/5 active:scale-90"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0L8 8m4-4v12"/></svg>
                      </button>
                    </div>
                  </div>
                );
              }) : (
                <div className="p-12 text-center bg-zinc-950 rounded-[40px] border border-dashed border-white/5">
                   <p className="text-[10px] font-black uppercase text-zinc-700 tracking-[0.2em]">Original Mix Only Available</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Artist Card & Stats */}
        <div className="lg:col-span-4 space-y-8">
          
          {/* Artist Identity Module */}
          <div className="bg-zinc-950 p-8 rounded-[48px] border border-white/5 space-y-8 shadow-2xl sticky top-32">
            <div className="flex flex-col items-center text-center space-y-6">
              <div 
                onClick={() => onArtistClick(track.artistId)}
                className="w-28 h-28 rounded-full overflow-hidden border-4 border-black shadow-[0_15px_40px_rgba(0,0,0,0.6)] cursor-pointer group"
              >
                <img src={track.artistAvatarUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              <div className="space-y-1">
                <h3 onClick={() => onArtistClick(track.artistId)} className="text-2xl font-black text-white cursor-pointer hover:text-[#ff5500] transition-colors tracking-tight">{track.artist}</h3>
                <div className="flex items-center justify-center gap-1.5 text-[9px] font-black text-[#ff5500] uppercase tracking-widest">
                   <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                   Verified Pool Producer
                </div>
              </div>
            </div>
            
            <p className="text-zinc-400 text-xs md:text-sm leading-relaxed text-center font-medium">
              {track.artistBio || "This elite producer has chosen to let their music speak for itself in the record pool."}
            </p>
            
            <button 
              onClick={() => onArtistClick(track.artistId)}
              className="w-full py-5 bg-white text-black text-[11px] font-black uppercase tracking-[0.2em] rounded-3xl hover:bg-zinc-200 active:scale-95 transition-all shadow-xl"
            >
              Artist Profile
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-zinc-900/40 border border-white/5 p-6 rounded-[36px] text-center shadow-lg">
              <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-2">Downloads</span>
              <span className="text-2xl font-black text-white">{(track.downloadCount || 0).toLocaleString()}</span>
            </div>
            <div className="bg-zinc-900/40 border border-white/5 p-6 rounded-[36px] text-center shadow-lg">
              <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-2">Pool Plays</span>
              <span className="text-2xl font-black text-white">{(track.plays || 0).toLocaleString()}</span>
            </div>
          </div>

        </div>
      </div>

      <style>{`
        @keyframes bar-bounce {
          0%, 100% { height: 4px; }
          50% { height: 20px; }
        }
        .animate-bar-bounce {
          animation: bar-bounce 0.8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default TrackDetail;
